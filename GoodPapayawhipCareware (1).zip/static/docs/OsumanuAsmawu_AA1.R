"
****************************************************************
Name:Asmawu Osumanu
Student Number:A00305301

QMM1002 Module 1 Applied Activity
****************************************************************
"

#############								   	                  
#Question #1							
#############
# reading the file Donors.csv into R#
D<-read.csv("Donors.csv", header = TRUE)
# a. finding the mean and standard deviation of age 
Md<-mean(D$Age)
Md
#62.38755
sdD<-sd(D$Age)
sdD
#16.12843
n<-length(D$Age)
n
# 916
#b. standard Error 
SE<-sdD/sqrt(n)
SE
# 0.5328982
# c. degrees of freedom
DF<-n-1
DF
#  915
#d. histogram
hist(D$Age)
# using boxplot
boxplot(D$Age)
# e. determining and interpreting 95% confidence interval for age
t.crit<-qt(0.975,n-1)
Md-t.crit*SE
# 61.34171
Md+t.crit*SE
# 63.4334
# I am 95% confidence that the age interval is between 62.34171 and 63.4334.


# f.how many people would need to be sampled to obtain a 99% confidence interval for the age with a margin of error of 0.5 years? 
ME<-t.crit*SE
ME
# ME is 1.045845
# approx with normal
N<-(qnorm(0.995)*sdD/ME)^2
# 1577.916
# update with t
N<-(qt(0.995, N-1)*sdD/ME)^2
N

# N(ceiling is 1581.742)

# g. 
#H0: mu = 39
#HA: mu > 39
# alpha = 0.05

t.test(D$Age, mu = 39, alternative = "greater")
# p-value is greater than alpha which is 0.05 therefore we fail to reject the hypothesis as there is no evidence to support the mean age of donors is above 39.
#h.
# finding the critical value 
qt(0.05, df = 915, lower.tail=FALSE)
# qt = 1.646521

# i.
Yes.homeowners<-subset(D, Homeowner=='H')
Yes.homeowners$Age
length(Yes.homeowners$Age)
# 727
unknown_homeowners <- subset(D, Homeowner== "U")
length(unknown_homeowners$Age)
#189
hist(Yes.homeowners$Age, probability = TRUE, col = "pink")
lines(density(Yes.homeowners$Age), col = "blue")


hist(unknown_homeowners$Age, probability = TRUE, col = "green")
lines(density(unknown_homeowners$Age), col = "red")
#There is no difference between the overall age and that of the age of the homeowners.

#
#k


#H0: mu = 60
#HA: mu != 60

t.test(Yes.homeowners$Age, mu=60, alternative = "two.sided")

#Reject the null hypothesis, there is sufficient evidence that the mean age of the homeowners is different from 60 yrs of age.


# i. determining and interpreting 95% confidence interval for age of homeownwers.

# 95% confidence interval is between 61  and 63 years.
#Q2.
p.data<-read.csv("personalised_dataset_2nd_sem.csv", header = TRUE)
p.data
mp<-mean(p.data$Study)
mp

sdp<-sd(p.data$Study)
sdp

n<-length(p.data$Age)
n
# 
#b. standard Error 
sep<-sdD/sqrt(n)
sep
  
 
 
# c. degrees of freedom
df<-n-1
df
#  
#d. histogram
hist(p.data$Study)

# e. determining and interpreting 95% confidence interval for age
t.crit<-qt(0.975,n-1)
Mp-t.crit*SE
# 
Md+t.crit*SE
# 
# 
